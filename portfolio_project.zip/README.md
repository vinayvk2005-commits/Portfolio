# Portfolio Website

## How to Use
1. Upload to GitHub
2. Go to Settings > Pages
3. Select branch 'main' and root folder
4. Your site will be live!

## Customize
- Change name in index.html
- Add your projects
- Update email
